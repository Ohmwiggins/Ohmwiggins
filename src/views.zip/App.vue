<template>
  <div>
     <nav class="navbar navbar-dark bg-dark">&emsp; 
      <img src="./assets/logo.png" width="30" height="30">
      <div class="container">
        <router-link to="/" class="navbar-brand float-left">Contact</router-link>
<!--         <ul class="nav navbar-nav flex-row float-right">
          <li class="nav-item">
            <router-link to="/create" class="nav-link">List</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/" class="nav-link">Update</router-link>
          </li>

          <li class="nav-item">
            <router-link to="/" class="nav-link">Update</router-link>
          </li>
        </ul> -->
        <router-link to="/" class="nav-link">Signin</router-link>

      </div>
      
    </nav>

    <div class="container"> 
      <router-view></router-view>
    </div>

  </div>
</template>

<script>
  export default {
  name: 'App',
  components: {
    
  }
}
</script>

