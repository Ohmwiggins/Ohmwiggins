<template>
    <div class="row justify-content-left">
        <div class="col-md-6">
            <!-- Content -->
            <div class="h2">Contact</div>
            <br>
            <br>
            <div class="form-grou">
                <label>Contact ID</label>
                <input type="text" class="form-control">
            </div>
        </div>   
    </div>     
</template>

<script>
export default {
    data() {
        return{
            
        }
    }
}
</script>