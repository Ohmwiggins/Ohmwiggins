<template>
    
    <br><br>
    <div class="input-group">
        <input type="text" class="form-control" placeholder="Search..." v-model="search">
        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
            <button @click="SEARCH()" type="button" class="btn btn-secondary">&nbsp;Search&nbsp;</button>
            <router-link to="/create">
                <button type="button" class="btn btn-warning">&nbsp; + Add&emsp; </button>
            </router-link>
        </div>
    </div>

    <br><br>

    <div  class="row row-cols-md-4">
        <div class="col" v-for="user_alias in filterUsers">
            <div class="card" style="width: 22rem;">
                <img  class="card-img-top" :src="user_alias.imageUrl" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">{{user_alias.firstname}}</h5>
                    Mobile: {{user_alias.mobile}}<br>
                    Email: {{user_alias.email}}<br>
                    Facebook: {{user_alias.facebook}}<br>
                    <br>
                    <div class="card-footer">
                        <router-link to="/create">
                            <a href="#" class="btn btn-primary"><img src="https://picsum.photos/200" class="buttonimg"/></a>
                        </router-link>
                        <a href="#" @click="DELETE(user_alias.cid)" class="btn btn-danger"><img src="https://picsum.photos/200" class="buttonimg"/></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
import axios from 'axios'
export default {
    name: 'Users',
    props: {

    },
    data() {
        return {
            search: '',
            Users: [],
            uid: '',
            filterUsers: []
        }
    },
    mounted() {
        axios.get('http://localhost:5000/contacts')
        .then((reponse)=>{
            console.log(reponse.data)
            this.Users = reponse.data
            this.filterUsers = reponse.data
        })
        .catch((error)=>{
            console.log(error)
        })
    },
    methods: {
		DELETE(id){
            axios.delete('http://localhost:5000/contacts/'+id)
            .then(()=>{
                console.log('Delete User ID: '+ id)
            })
            .catch((error)=>{
                console.log(error)
            })
          window.location.reload()
        },
        SEARCH(){
            this.filterUsers = this.Users.filter((user)=> user.firstname.toLowerCase().match(this.search.toLowerCase()))
        }
    },
}
</script>

<style scoped>
.card {
    margin: 10px;
}
.buttonimg {
    width: 10px;
    height: 10px;
}
</style>